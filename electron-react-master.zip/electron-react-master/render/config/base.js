const env = require('electron').remote.require('./main_process/env');

export default env.handleEnv;