global.__dirname = __dirname;
global.myField = { name: 'ConardLi' };

require('./main_process/index.js');
